#include "StarGenerator.h"

class StarSystem {
private:
	int numOfGenerators;
	Generator ** generators;


public:
	StarSystem(int num, int *x_axis, int *y_axis, int *z_axis) {
		numOfGenerators = num;
		
		generators = (Generator**) new StarGenerator*[num];
		for (int i = 0; i < num; i++) {
			generators[i] = new StarGenerator((float)x_axis[i], (float)y_axis[i], (float)z_axis[i]);
		}
			
	}

	~StarSystem() {
		for (int i = 0; i < numOfGenerators; i++)
			delete generators[i];
		delete[] generators;
	}

	void particleSystemLoop() {
		for (int i = 0; i < numOfGenerators; i++)
			generators[i]->particleLoop();
		
	}
};