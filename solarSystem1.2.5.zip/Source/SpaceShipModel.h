#pragma once

#include "Model.h"

class SpaceShipModel : public Model
{
	public:
		SpaceShipModel(glm::vec3 size = glm::vec3(1.0f, 1.0f, 1.0f));
		virtual ~SpaceShipModel(void);

		virtual int GetModelType();
		virtual void SetModelType(int type);

		virtual void Update(float dt);
		virtual void Draw();

	protected:
		virtual bool ParseLine(const std::vector<ci_string>& token);
	private:
		struct Vertex
		{
			glm::vec3 position;
			glm::vec3 normal;
			glm::vec3 color;
		};

		int check;
		unsigned int mVAO;
		unsigned int mVBO;
		unsigned int numOfVertices;
};