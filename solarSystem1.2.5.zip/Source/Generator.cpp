#include "Generator.h"

Generator::Generator() {

}

Generator::~Generator() {
	delete[] stars;
}

void Generator::particleDisplay(int i) {
	
	glColor4f(stars[i].color.x,
			  stars[i].color.y,
			  stars[i].color.z,
			  stars[i].life);

	glPointSize(starSize);

	glBegin(GL_POINTS);
	glVertex3f(stars[i].position.x,
			   stars[i].position.y,
			   stars[i].position.z);
	glEnd();
}

void Generator::particleLoop() {
	for (int i = 0; i < starNumber; i++) {
		particleDisplay(i);
		particleUpdate(i);
	}
}