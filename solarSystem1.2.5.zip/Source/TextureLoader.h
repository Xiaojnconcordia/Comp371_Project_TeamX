//
// COMP 371 Assignment Framework
//
// Created by Nicolas Bergeron on 15/7/15.
//
// Copyright (c) 2014-2019 Concordia University. All rights reserved.
//

#pragma once
//#include <vector>

// Simple Texture Loader Class
class TextureLoader
{
public:
    static int LoadTexture(const char * imagepath);

	//static unsigned int loadCubemap(std::vector<std::string> faces);
	//static unsigned int loadSkyTexture(char const * path);

private:
    
};
