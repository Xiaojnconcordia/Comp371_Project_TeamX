#include "Material.h"


Material::Material(unsigned int _diffuse, unsigned int _specular, glm::vec3 _ambient, float _shininess) :
	diffuse(_diffuse), specular(_specular), ambient(_ambient), shininess(_shininess)
{

}

