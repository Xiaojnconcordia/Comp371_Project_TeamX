//
// COMP 371 team X project Framework
//
// Created by teamX on 8/3/19.
//
//

#pragma once

#include "Model.h"


class CubeModel : public Model
{
public:
	CubeModel(glm::vec3 size = glm::vec3(1.0f, 1.0f, 1.0f));
	virtual ~CubeModel();

	virtual void Update(float dt);
	virtual void Draw();
	virtual int GetModelType();
	virtual void SetModelType(int type);

	unsigned int loadCubemap(std::vector<std::string> faces);
	//unsigned int LoadImageToGPU(const char* filename, GLint internalFormat, GLenum format, int textureSlot);
	unsigned int loadSkyTexture(char const * path);

protected:
	virtual bool ParseLine(const std::vector<ci_string> &token);

private:
	// The vertex format could be different for different types of models
	struct Vertex
	{
		glm::vec3 position;
		glm::vec3 normal;
		glm::vec3 color;
	
	};
	int check=0;

	unsigned int cubeTexture;
	unsigned int cubemapTexture;

	unsigned int mVAO;
	unsigned int mVBO;
};
