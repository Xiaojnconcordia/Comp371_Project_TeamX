//
// COMP 371 Assignment Framework
//
// Created by Nicolas Bergeron on 8/7/14.
// Updated by Gary Chang on 14/1/15
//
// Copyright (c) 2014-2019 Concordia University. All rights reserved.
//
#pragma once
#include "World.h"
#include "Renderer.h"
#include "ParsingHelper.h"
#include "Material.h"

#include "StaticCamera.h"
#include "ThirdOrFirstPersonCamera.h"
#include "CubeModel.h"
#include "SphereModel.h"
#include "Animation.h"
#include "Billboard.h"
#include <GLFW/glfw3.h>
#include "EventManager.h"
#include "TextureLoader.h"

#include "BSpline.h"
#include "BSplineCamera.h"
#include "ParticleDescriptor.h"
#include "ParticleEmitter.h"
#include "ParticleSystem.h"

#include "StarSystem.h"

using namespace std;
using namespace glm;

World* World::instance;

static ThirdOrFirstPersonCamera* spaceShipCamera = new ThirdOrFirstPersonCamera(vec3(10.0f, 15.0f, 30.0f));
static vec3 earthPosition(17.0, 2.0, 0.0);

int x[] = { 70,10,-80,16 };
int y[] = { 20,20,20,40 };
int z[] = { 10,10,30,-10 };
StarSystem * star = new StarSystem(4, x, y, z);


World::World()
{
    instance = this;


	ambientSphere = 0.4f;
	diffuseSphere = 0.8f;
	specularSphere = 0.5f;
	exponentSphere = 32.0f;

	lightColor = vec3(1.0f, 1.0f, 1.0f);
	lightPosition = vec4(0.0f, 2.0f, 0.0f, 1.0f);
	kc = 0.001f;
	kl = 0.001f;
	kq = 0.002f;

	// Setup Camera
	
	mCamera.push_back(spaceShipCamera);
	mCamera.push_back(new StaticCamera(vec3(3.0f, 42.0f, 5.0f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f)));
	mCamera.push_back(new StaticCamera(vec3(42.5f, 42.5f, 42.5f), vec3(0.0f, 0.5f, 0.0f), vec3(0.0f, 1.0f, 0.0f)));
	mCurrentCamera = 0;

    
#if defined(PLATFORM_OSX)
//    int billboardTextureID = TextureLoader::LoadTexture("Textures/BillboardTest.bmp");
    int billboardTextureID = TextureLoader::LoadTexture("Textures/Particle.png");
#else
//    int billboardTextureID = TextureLoader::LoadTexture("../Assets/Textures/BillboardTest.bmp");
    int billboardTextureID = TextureLoader::LoadTexture("../Assets/Textures/Particle.png");

#endif
    assert(billboardTextureID != 0);

    mpBillboardList = new BillboardList(2048, billboardTextureID);
}

World::~World()
{
	// Models
	for (vector<Model*>::iterator it = mModel.begin(); it < mModel.end(); ++it)
	{
		delete *it;
	}

	mModel.clear();

	for (vector<Animation*>::iterator it = mAnimation.begin(); it < mAnimation.end(); ++it)
	{
		delete *it;
	}

	mAnimation.clear();

	for (vector<AnimationKey*>::iterator it = mAnimationKey.begin(); it < mAnimationKey.end(); ++it)
	{
		delete *it;
	}

	mAnimationKey.clear();

	// Camera
	for (vector<Camera*>::iterator it = mCamera.begin(); it < mCamera.end(); ++it)
	{
		delete *it;
	}
	mCamera.clear();
    
    for (vector<ParticleSystem*>::iterator it = mParticleSystemList.begin(); it < mParticleSystemList.end(); ++it)
    {
        delete *it;
    }
    mParticleSystemList.clear();
    
    for (vector<ParticleDescriptor*>::iterator it = mParticleDescriptorList.begin(); it < mParticleDescriptorList.end(); ++it)
    {
        delete *it;
    }
    mParticleDescriptorList.clear();

    
	delete mpBillboardList;
}

World* World::GetInstance()
{
    return instance;
}

void World::Update(float dt)
{
	// User Inputs
	// 0 1 2 to change the Camera
	if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_1 ) == GLFW_PRESS)
	{
		mCurrentCamera = 0;
	}
	else if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_2 ) == GLFW_PRESS)
	{ 
		if (mCamera.size() > 1)
		{
			mCurrentCamera = 1;
		}
	}
	else if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_3 ) == GLFW_PRESS)
	{
		if (mCamera.size() > 2)
		{
			mCurrentCamera = 2;
		}
	}

	// press 0,9 to change the shader
	if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_0 ) == GLFW_PRESS)
	{
		Renderer::SetShader(SHADER_SOLID_COLOR);
	}
	else if (glfwGetKey(EventManager::GetWindow(), GLFW_KEY_9 ) == GLFW_PRESS)
	{
		Renderer::SetShader(SHADER_BLUE);
	}

    // Update animation and keys
    for (vector<Animation*>::iterator it = mAnimation.begin(); it < mAnimation.end(); ++it)
    {
        (*it)->Update(dt);
    }
    
    for (vector<AnimationKey*>::iterator it = mAnimationKey.begin(); it < mAnimationKey.end(); ++it)
    {
        (*it)->Update(dt);
    }


	// Update current Camera
	mCamera[mCurrentCamera]->Update(dt);

	// Update models
	for (vector<Model*>::iterator it = mModel.begin(); it < mModel.end(); ++it)
	{
		//space ship head
		if ((*it)->GetModelType() == 10)
		{
			(*it)->SetPosition(spaceShipCamera->cameraOriginPosition());
			//(*it)->SetRotation(vec3(0, 1, 0), spaceShipCamera->GetmHorizontalAngle()/26);
			//(*it)->SetRotation(vec3(1, 0, 1), spaceShipCamera->GetmVerticalAngle());
		}
		//space ship body
		else if ((*it)->GetModelType() == 11)
		{
			(*it)->SetPosition(spaceShipCamera->cameraOriginPosition() - vec3(0, 0.1, 0));
		}
		//emitting point of stars that is going behind
		else if ((*it)->GetModelType() == 20)
		{
			(*it)->SetPosition(spaceShipCamera->cameraOriginPosition()
				+ spaceShipCamera->getMlookAt() * 100.0f);
			//always at the front of camera, away from camera for 100 units
		}
		//earth
		else if ((*it)->GetModelType() == 2)
		{
			earthPosition = (*it)->GetPosition();
		}
		//lunar 
		else if ((*it)->GetModelType() == 3)
		{
			(*it)->SetRotation(vec3(0.0f, 1.0f, 0.0f), dt * 20);
		}
		(*it)->Update(dt);
	}
    
    // Update billboards
    
    for (vector<ParticleSystem*>::iterator it = mParticleSystemList.begin(); it != mParticleSystemList.end(); ++it)
    {
        (*it)->Update(dt);
    }
    
    mpBillboardList->Update(dt);
}

void World::Draw()
{
	Renderer::BeginFrame();
	//star
	star->particleSystemLoop();

	// Set shader to use
	glUseProgram(Renderer::GetShaderProgramID());

	// This looks for the MVP Uniform variable in the Vertex Program
	GLuint VPMatrixLocation = glGetUniformLocation(Renderer::GetShaderProgramID(), "ViewProjectionTransform");

	//project
	Renderer::SetShader(SHADER_PLANETTEXTURE);
	GLuint ViewMatrixLocation = glGetUniformLocation(Renderer::GetShaderProgramID(), "ViewTransform");
	GLuint ProjectionMatrixLocation = glGetUniformLocation(Renderer::GetShaderProgramID(), "ProjectonTransform");

	GLuint LightPositionID = glGetUniformLocation(Renderer::GetShaderProgramID(), "WorldLightPosition");
	GLuint LightColorID = glGetUniformLocation(Renderer::GetShaderProgramID(), "lightColor");
	GLuint LightAttenuationID = glGetUniformLocation(Renderer::GetShaderProgramID(), "lightAttenuation");

	GLuint MaterialID = glGetUniformLocation(Renderer::GetShaderProgramID(), "materialCoefficients");

	// Send the view projection constants to the shader
	mat4 VP = mCamera[mCurrentCamera]->GetViewProjectionMatrix();
	glUniformMatrix4fv(VPMatrixLocation, 1, GL_FALSE, &VP[0][0]);

	//project
	glUniform4f(MaterialID, ambientSphere, diffuseSphere, specularSphere, exponentSphere);
	glUniform4f(LightPositionID, lightPosition.x, lightPosition.y, lightPosition.z, lightPosition.w);
	glUniform3f(LightColorID, lightColor.r, lightColor.g, lightColor.b);
	glUniform3f(LightAttenuationID, kc, kl, kq);

	glUniformMatrix4fv(ViewMatrixLocation, 1, GL_FALSE, &(mCamera[mCurrentCamera]->GetViewMatrix())[0][0]);
	glUniformMatrix4fv(ProjectionMatrixLocation, 1, GL_FALSE, &(mCamera[mCurrentCamera]->GetProjectionMatrix())[0][0]);
	// Draw models
	for (vector<Model*>::iterator it = mModel.begin(); it < mModel.end(); ++it)
	{
		//(*it)->planetTextureID = getTextureID((*it)->GetModelType());
		// we do not draw sun model here, will draw it later so it will not be effected with light effect
		if (((*it)->GetModelType() == 4))
		{
			continue;
		}

		(*it)->Draw();
	}

	// Draw Path Lines
	
	// Set Shader for path lines
	unsigned int prevShader = Renderer::GetCurrentShader();
	Renderer::SetShader(SHADER_PATH_LINES);
	glUseProgram(Renderer::GetShaderProgramID());

	// Send the view projection constants to the shader
	VPMatrixLocation = glGetUniformLocation(Renderer::GetShaderProgramID(), "ViewProjectionTransform");
	glUniformMatrix4fv(VPMatrixLocation, 1, GL_FALSE, &VP[0][0]);

	for (vector<BSpline*>::iterator it = mSpline.begin(); it < mSpline.end(); ++it)
	{
		(*it)->Draw();
	}

	for (vector<Animation*>::iterator it = mAnimation.begin(); it < mAnimation.end(); ++it)
	{
		mat4 VP = mCamera[mCurrentCamera]->GetViewProjectionMatrix();
		glUniformMatrix4fv(VPMatrixLocation, 1, GL_FALSE, &VP[0][0]);

		(*it)->Draw();
	}

	for (vector<AnimationKey*>::iterator it = mAnimationKey.begin(); it < mAnimationKey.end(); ++it)
	{
		mat4 VP = mCamera[mCurrentCamera]->GetViewProjectionMatrix();
		glUniformMatrix4fv(VPMatrixLocation, 1, GL_FALSE, &VP[0][0]);

		(*it)->Draw();
	}
	// Draw models in static shader, only used for sun model, so the sun has no ambient light
	for (vector<Model*>::iterator it = mModel.begin(); it < mModel.end(); ++it)
	{
		if (((*it)->GetModelType() == 4))
		{
			Renderer::SetShader(SHADER_SOLID_COLOR);
			glUseProgram(Renderer::GetShaderProgramID());
			GLuint VPMatrixLocation = glGetUniformLocation(Renderer::GetShaderProgramID(), "ViewProjectionTransform");
			mat4 VP = mCamera[mCurrentCamera]->GetViewProjectionMatrix();
			glUniformMatrix4fv(VPMatrixLocation, 1, GL_FALSE, &VP[0][0]);
			(*it)->Draw();
		}
	}
    Renderer::CheckForErrors();
    
    // Draw Billboards
    glEnable(GL_BLEND);
    //glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE); //project
    mpBillboardList->Draw();
    glDisable(GL_BLEND);

	// Restore previous shader
	Renderer::SetShader((ShaderType) prevShader);

	Renderer::EndFrame();
}

void World::LoadScene(const char * scene_path)
{
	// Using case-insensitive strings and streams for easier parsing
	ci_ifstream input;
	input.open(scene_path, ios::in);

	// Invalid file
	if(input.fail() )
	{	 
		fprintf(stderr, "Error loading file: %s\n", scene_path);
		getchar();
		exit(-1);
	}

	ci_string item;
	while( std::getline( input, item, '[' ) )   
	{
        ci_istringstream iss( item );

		ci_string result;
		if( std::getline( iss, result, ']') )
		{
			if( result == "cube" )
			{
				// Box attributes
				CubeModel* cube = new CubeModel();
				cube->Load(iss);
				mModel.push_back(cube);
			}
			else if (result == "galaxy")
			{
				// Sky Box
				CubeModel* cube = new CubeModel();
				cube->Load(iss);
				//cube->SetModelType(5);
				mModel.push_back(cube);
			}
			else if (result == "sun") {
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/sun2.png");
				sphere->SetModelType(4);
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
            else if( result == "Mercury" )
            {
                SphereModel* sphere = new SphereModel();
                sphere->Load(iss);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/mercury2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
            }
			else if (result == "venus")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/venus2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "earth")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(2);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/earthmap.jpg");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "lunar")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(3);
				//sphere->planetTextureID = getTextureID(sphere->GetModelType());
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/lunar2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				sphere->SetPosition(earthPosition + vec3(0.3, 0, 0));
				mModel.push_back(sphere);
			}
			else if (result == "Mars")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(7);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/mars2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "Jupiter")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(7);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/jupiter2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID,vec3(1.0f,1.0f,1.0f),32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "Saturn")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(7);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/saturn2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "Uranus")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(7);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/uranus2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "Naptune")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(7);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/neptune2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "Comet")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/sunmap.jpg");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "sphere")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/saturnringcolor.jpg");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				mModel.push_back(sphere);
			}
			else if (result == "spaceshiphead")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(10);
				//sphere->SetPosition(spaceShipCamera->cameraOriginPosition());
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/neptune2.png");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);

				mModel.push_back(sphere);
			}
			else if (result == "spaceshipbody")
			{
				SphereModel* sphere = new SphereModel();
				sphere->Load(iss);
				sphere->SetModelType(11);
				sphere->planetTextureID = TextureLoader::LoadTexture("../Assets/Textures/planetsMaps/saturnringcolor.jpg");
				sphere->planetMaterial = new Material(sphere->planetTextureID, sphere->planetTextureID, vec3(1.0f, 1.0f, 1.0f), 32.0f);
				sphere->SetPosition(spaceShipCamera->cameraOriginPosition());

				mModel.push_back(sphere);
			}
			else if (result == "starGoingBehind")
			{
			SphereModel* sphere = new SphereModel();
			sphere->Load(iss);
			sphere->SetModelType(20);
			//sphere->SetPosition(spaceShipCamera->cameraOriginPosition());

			mModel.push_back(sphere);
			}
			else if ( result == "animationkey" )
			{
				AnimationKey* key = new AnimationKey();
				key->Load(iss);
				mAnimationKey.push_back(key);
			}
			else if (result == "animation")
			{
				Animation* anim = new Animation();
				anim->Load(iss);
				mAnimation.push_back(anim);
			}
			else if (result == "spline")
			{
				BSpline* spline = new BSpline();
				spline->Load(iss);
				spline->CreateVertexBuffer();

				// FIXME: This is hardcoded: replace last camera with spline camera
				mSpline.push_back(spline);
				mCamera.pop_back();
				mCamera.push_back(new BSplineCamera(spline, 10.0f));
			}
            else if (result == "particledescriptor")
            {
                ParticleDescriptor* psd = new ParticleDescriptor();
                psd->Load(iss);
                AddParticleDescriptor(psd);
            }
			else if ( result.empty() == false && result[0] == '#')
			{
				// this is a comment line
			}
			else
			{
				fprintf(stderr, "Error loading scene file... !");
				getchar();
				exit(-1);
			}
	    }
	}
	input.close();

	// Set Animation vertex buffers
	for (vector<Animation*>::iterator it = mAnimation.begin(); it < mAnimation.end(); ++it)
	{
		// Draw model
		(*it)->CreateVertexBuffer();
	}
}

Animation* World::FindAnimation(ci_string animName)
{
    for(std::vector<Animation*>::iterator it = mAnimation.begin(); it < mAnimation.end(); ++it)
    {
        if((*it)->GetName() == animName)
        {
            return *it;
        }
    }
    return nullptr;
}

AnimationKey* World::FindAnimationKey(ci_string keyName)
{
    for(std::vector<AnimationKey*>::iterator it = mAnimationKey.begin(); it < mAnimationKey.end(); ++it)
    {
        if((*it)->GetName() == keyName)
        {
            return *it;
        }
    }
    return nullptr;
}

const Camera* World::GetCurrentCamera() const
{
     return mCamera[mCurrentCamera];
}

void World::AddBillboard(Billboard* b)
{
    mpBillboardList->AddBillboard(b);
}

void World::RemoveBillboard(Billboard* b)
{
    mpBillboardList->RemoveBillboard(b);
}

void World::AddParticleSystem(ParticleSystem* particleSystem)
{
    mParticleSystemList.push_back(particleSystem);
}

void World::RemoveParticleSystem(ParticleSystem* particleSystem)
{
    vector<ParticleSystem*>::iterator it = std::find(mParticleSystemList.begin(), mParticleSystemList.end(), particleSystem);
    mParticleSystemList.erase(it);
}

void World::AddParticleDescriptor(ParticleDescriptor* particleDescriptor)
{
    mParticleDescriptorList.push_back(particleDescriptor);
}



ParticleDescriptor* World::FindParticleDescriptor(ci_string name)
{
    for(std::vector<ParticleDescriptor*>::iterator it = mParticleDescriptorList.begin(); it < mParticleDescriptorList.end(); ++it)
    {
        if((*it)->GetName() == name)
        {
            return *it;
        }
    }
    return nullptr;
}
