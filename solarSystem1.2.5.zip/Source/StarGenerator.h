#pragma once
#include <GL/glew.h>
#include <glm/glm.hpp>
#include "Generator.h"


class StarGenerator : public Generator {
public:
	StarGenerator();
	StarGenerator(GLfloat x, GLfloat y, GLfloat z);
	~StarGenerator();

	virtual void particleInit(int i);
	virtual void particleUpdate(int i);

};