#pragma once
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <GLFW/glfw3.h>
#include <stdlib.h>
 #include <GL/gl.h>  
#include <GL/glu.h>

//#include <math.h>  
//#include <time.h>  
//#include <vector>  

using namespace std;
using namespace glm;


class StarParticle {
public:
	glm::vec3 color;
	glm::vec3 position;
	glm::vec3 velocity;
	glm::vec3 acceleration;
	
	GLfloat life;
	GLfloat attenuation;

	StarParticle();
	
	~StarParticle();
};
