#include "StarParticle.h"

StarParticle::StarParticle() {

}

StarParticle::~StarParticle() {

}




