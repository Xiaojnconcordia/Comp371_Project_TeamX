//
// COMP 371 team X project Framework
//
// Created by teamX on 8/3/19.
//
//
#pragma once

#include "Camera.h"


class ThirdOrFirstPersonCamera : public Camera
{
public:
	
	ThirdOrFirstPersonCamera(glm::vec3 position);
	virtual ~ThirdOrFirstPersonCamera();

	virtual void Update(float dt);

	virtual glm::mat4 GetViewMatrix() const;

	virtual glm::vec3 cameraOriginPosition();
	
	virtual float GetmHorizontalAngle();
	virtual float GetmVerticalAngle();
	glm::vec3 getMlookAt() { return mLookAt; }
		
	
private:
	glm::vec3 mPosition;	
	float mHorizontalAngle; // horizontal angle
	float mVerticalAngle;   // vertical angle

	float mSpeed;			// World units per second
	float mAngularSpeed;    // Degrees per pixel
	bool  cameraFirstPerson;
	
	glm::vec3 mLookAt;
};
