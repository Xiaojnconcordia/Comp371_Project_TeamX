#include"StarGenerator.h"

const int colorCount_stars = 10;

vec3 colorArray[colorCount_stars] = {
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(1.0f / 255, 1.0f / 255, 1.0f / 255),
	vec3(255.0f / 255, 255.0f / 255, 255.0f / 255)
};


StarGenerator::StarGenerator() {

 }

StarGenerator::StarGenerator(GLfloat x, GLfloat y, GLfloat z) {

		offset = vec3(x, y, z);
		starNumber = 400;
		stars = new StarParticle[starNumber];

		colorList = colorArray;
		colorCount = colorCount_stars;

		starSize = 0.5;
		starLife = 0.75;
}

StarGenerator::~StarGenerator() {
		delete[] stars;
}
	
void StarGenerator::particleInit(int i) {
		float areaX = 100;
		float areaY = 100;
		float areaZ = 100;

		stars[i].life = starLife * (rand() % 100) * 0.01f;
		stars[i].attenuation = 0.006f;
		//set color
		
		stars[i].color.x = colorList[colorCount - 1].x;
		stars[i].color.y = colorList[colorCount - 1].y;
		stars[i].color.z = colorList[colorCount - 1].z;

		//set position
		stars[i].position.x = (float)(areaX / 2 - areaX * (rand() % 100)*0.01);
		stars[i].position.y = (float)(areaY / 2 - areaY * (rand() % 100)*0.01);
		stars[i].position.z = (float)(areaZ / 2 - areaZ * (rand() % 100)*0.01);

		//set velocity
		stars[i].velocity.x = 0;
		stars[i].velocity.y = 0;
		stars[i].velocity.z = 0.05f;

		//set acceleration
		stars[i].acceleration.x = 0;
		stars[i].acceleration.y = 0;
		stars[i].acceleration.z = 0;

		//set offset
		stars[i].position.x += offset.x;
		stars[i].position.y += offset.y;
		stars[i].position.z += offset.z;

		
}

 void StarGenerator::particleUpdate(int i) {
		if (stars[i].life < 0.0f) {
			particleInit(i);
		}
		else{
			//set new position
			stars[i].position.x += stars[i].velocity.x;
			stars[i].position.y += stars[i].velocity.y;
			stars[i].position.z += stars[i].velocity.z;

			//set new velocity
			stars[i].velocity.x += stars[i].acceleration.x;
			stars[i].velocity.y += stars[i].acceleration.y;
			stars[i].velocity.z += stars[i].acceleration.z;

			stars[i].life -= stars[i].attenuation;
			
			//GLuint colorPos = (GLuint)(stars[i].life / starLife * (colorCount - 1));
			/*stars[i].color.x = colorList[colorPos][0] / 255.0f;
			stars[i].color.y = colorList[colorPos][1] / 255.0f;
			stars[i].color.z = colorList[colorPos][2] / 255.0f;*/

			float t = (starLife - stars[i].life )/ starLife;
			glm::vec3 initialColor(1.0,1.0,1.0);
			glm::vec3 endColor(0.0, 0.0, 0.0);
			stars[i].color = mix(initialColor, endColor, t);

			
			/*stars[i].position.x = (float)(1 - rand() % 20 * 0.1);
			stars[i].velocity.x = stars[i].position.x / 10; 
			stars[i].position.x += offset.x; */
		}
}

