//
// COMP 371 team X project Framework
//
// Created by teamX on 8/3/19.
//
//

#pragma once

#include "Model.h"
#include "Material.h"

class SphereModel : public Model
{
public:
	SphereModel(glm::vec3 size = glm::vec3(1.0f, 1.0f, 1.0f));
    virtual ~SphereModel(void);

	virtual int GetModelType();
	virtual void SetModelType(int type);

    virtual void Update(float dt);
	virtual void Draw();

	Material * planetMaterial;
    
protected:
    virtual bool ParseLine(const std::vector<ci_string> &token);

private:
    // The vertex format could be different for different types of models
    struct Vertex
    {
        glm::vec3 position;
        glm::vec3 normal;
        glm::vec3 color;

		glm::vec2 textureCoordinate;
    };

	std::vector<Vertex> mVertexBuffer;

	int check = 0;
    unsigned int mVAO;
    unsigned int mVBO;
    unsigned int numOfVertices;

	//unsigned int planetTextureID;
};


