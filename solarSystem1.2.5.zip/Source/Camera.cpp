//
// COMP 371 team X project Framework
//
// Created by teamX on 8/3/19.
//
//

#include "Camera.h"
#include <glm/gtx/transform.hpp>
#include <GLFW/glfw3.h>
using namespace glm;

Camera::Camera()
{
}

Camera::~Camera()
{
}

mat4 Camera::GetViewProjectionMatrix() const
{
	// @TODO 1 - Calculate View Projection Matrix
	//           The projection matrix is hardcoded below
	//           The view matrix is set in the derived camera classes.
	
    mat4 viewProjection(1.0f);   
	
	viewProjection = GetProjectionMatrix() * GetViewMatrix();
    return viewProjection;
}

mat4 Camera::GetProjectionMatrix() const
{
	return perspective(45.0f, 4.0f / 3.0f, 0.1f, 200.0f);
}
