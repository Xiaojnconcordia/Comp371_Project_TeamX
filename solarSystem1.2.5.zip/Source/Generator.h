#pragma once
#include <GL/glew.h>
#include <glm/glm.hpp>
#include "StarParticle.h"
class Generator {
protected:
	GLuint starNumber;
	StarParticle * stars;

	GLuint colorCount;
	vec3 *colorList;
	//GLuint (*colorList)[3];
	vec3 offset;

	GLfloat starLife;
	GLfloat starSize;

public:

	virtual void particleInit(int i) = 0;

	virtual void particleUpdate(int i) = 0;

	void particleDisplay(int);

	void particleLoop();

	Generator();
	~Generator();


};
